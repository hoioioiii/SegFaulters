﻿using System;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.ComponentModel;
using Project1;
using System.Reflection.Metadata;
using System.Xml.Linq;
using static Project1.Constants;
using Project1.Items.sprites;

namespace Project1
{
    public class EndingFramesSpriteFactory
    {

        private Texture2D[] Explosion = new Texture2D[4];
       
        

    }

}