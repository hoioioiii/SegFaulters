﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Project1.Constants;
namespace Project1
{
    public interface IPlayerMovement
    {

        public void Move(Direction direction);
    }
}
