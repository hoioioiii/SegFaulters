﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;
//using static Project1.Constants;

//namespace Project1
//{
//    public class UniversalWeaponClass : IWeapon
//    {
//        private ISpriteWeapon sprite;
//        public UniversalWeaponClass()
//        {
//            sprite = WeaponSpriteFactory.Instance.CreateOrbSprite();
//        }
//        public Rectangle BoundingBox { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

//        public void Attack()
//        {
//            throw new NotImplementedException();
//        }

//        public void Attack(int x, int y, Constants.Direction direct)
//        {
//            throw new NotImplementedException();
//        }

//        public void DetermineWeaponState()
//        {
//            throw new NotImplementedException();
//        }

//        public void Draw(SpriteBatch spriteBatch)
//        {
//            throw new NotImplementedException();
//        }

//        public void Draw()
//        {
//            throw new NotImplementedException();
//        }

//        public bool finished()
//        {
//            throw new NotImplementedException();
//        }

//        public void GetUserPos()
//        {
//            throw new NotImplementedException();
//        }

//        public void GetUserState()
//        {
//            throw new NotImplementedException();
//        }

//        public void Load()
//        {
//            throw new NotImplementedException();
//        }

//        public void Update()
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
