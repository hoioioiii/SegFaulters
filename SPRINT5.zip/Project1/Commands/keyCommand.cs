﻿using Project1.HUD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    internal class keyCommand : ICommand
    {
        public void Execute()
        {

        }
    }
}
