using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;

namespace Project1
{
    /*
     * This is to test the items
     * 
     */
    public interface IListIterate
    {
        public void CreateList(Texture2D[] temp);
        //public void moveBack();
        //public void moveForward();
        public void Load();


    }
}
