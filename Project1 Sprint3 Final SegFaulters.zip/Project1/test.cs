using System;
namespace Application
{
	public class test
	{
		public test()
		{
		}
	}
}

